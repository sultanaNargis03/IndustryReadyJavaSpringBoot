package com.Courses.main;

public interface CourseList 
{
   boolean courseChoice(double amount);
}
