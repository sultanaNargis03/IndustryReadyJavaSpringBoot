package com.Courses.main;

import com.Courses.dao.Java;
import com.Courses.dao.SQL;
import com.Courses.dao.SpringBoot;
import com.Courses.service.ProcessCourse;

public class LaunchMain 
{

	public static void main(String[] args) 
	{
		//ConstructorInjection
		ProcessCourse pc=new ProcessCourse(new Java());
		
//		int age=18;
//		age=14;
		//Java j=new Java();
		//pc.setCourse(j);
		
		//pc.setCourse(new SQL());
		
		//SetterInjection
		pc.setCourse(new SpringBoot());
		
		pc.processCourse(15444.4);

	}

}
