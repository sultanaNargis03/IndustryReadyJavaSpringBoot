package com.Courses.service;

import com.Courses.main.CourseList;

public class ProcessCourse 
{
	
	private CourseList course;

	//ConstructorInjection
	public ProcessCourse(CourseList course) {
		super();
		this.course = course;
	}
	
	
	//CourseList course=new Java(); 
	//CourseList course=new SQL();
	
	//CourseList course=new SpringBoot();
	
	

	//setterInjection
	public void setCourse(CourseList course) 
	{
		this.course = course;
	}
	
	public boolean processCourse(double amount)
	{
		
		boolean status=course.courseChoice(amount);
		
		if(status)
			System.out.println("Successfully selected the course. All the best");
		else
			System.out.println("error is processing with course enrollment");
		
		return true;
	}
	
	

}
