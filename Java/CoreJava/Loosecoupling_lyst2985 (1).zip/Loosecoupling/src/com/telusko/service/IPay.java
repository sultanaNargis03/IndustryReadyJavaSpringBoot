package com.telusko.service;

public interface IPay 
{
	boolean payBill(double amount);

}
