package com.telusko.service;

import com.telusko.dao.*;

public class PaymentProcess //extends DebitCard rejected multiple inheirtance is not allowed
{
	private IPay pay;
	
	//ConstructorInjection
	public PaymentProcess(IPay pay) {
		super();
		this.pay = pay;
	}

	//setter injection
	public void setPay(IPay pay) //IPay pay=new DebitCard();
	{
		this.pay = pay;
	}

	public boolean doPayment(double amount)
	{
		boolean status=pay.payBill(amount);
		
		if(status)
		{
			System.out.println("Payment success");
		}
		else
		{
			System.out.println("Payment Failed");
		}
		return true;
	}

}
