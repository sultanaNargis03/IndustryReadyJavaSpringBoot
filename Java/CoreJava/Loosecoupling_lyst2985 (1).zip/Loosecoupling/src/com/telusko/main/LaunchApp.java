package com.telusko.main;

import java.util.Scanner;

import com.telusko.dao.CreditCard;
import com.telusko.dao.DebitCard;
import com.telusko.dao.QRCode;
import com.telusko.service.PaymentProcess;

public class LaunchApp 
{

	public static void main(String[] args) 
	{
//		PaymentProcess pp=new PaymentProcess();
//		DebitCard db=new DebitCard();
//		pp.setPay(db);
		System.out.println("Welcome to fuel station choose the option");
		Scanner scan=new Scanner(System.in);
		
		System.out.println("CreditCard enter 01 : DebitCard enter 02 : QR enter 03");
		int option=scan.nextInt();
		if(option==2)
		{
			//setter injection
		  //pp.setPay(new DebitCard());
			
			//ConstructorInjection
			PaymentProcess pp=new PaymentProcess(new DebitCard());
		  pp.doPayment(55.4);
		}
		else if(option==1)
		{
			//setter injection
			//pp.setPay(new CreditCard());
			
			//ConstructorInjection
			PaymentProcess pp=new PaymentProcess(new DebitCard());
			 pp.doPayment(55.4);
		}
		else if(option==3)
		{
			//setter injection
			//pp.setPay(new QRCode());
			
			//ConstructorInjection
			PaymentProcess pp=new PaymentProcess(new DebitCard());
			 pp.doPayment(55.4);
		}
		else
		{
			System.out.println("Choose again among 1 0r 2 0r 3");
		}
		
		//pp.doPayment(100.5);

	}

}
