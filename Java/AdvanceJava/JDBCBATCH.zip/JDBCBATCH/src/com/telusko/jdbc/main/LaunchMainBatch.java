package com.telusko.jdbc.main;

import java.sql.*;


import com.telusko.jdbc.util.JdbcUtility;

public class LaunchMainBatch 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		//Resource
		Connection connect=null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		
		
		try
		{
			connect=JdbcUtility.getDBConnection();
			if(connect!=null)
			{
				String query="UPDATE studentinfo set saddr=? where sid=? ";
				stmt=connect.prepareStatement(query);
			}
			if(stmt!=null)
			{
			
				
				stmt.setString(1, "Mysuru");
				stmt.setInt(2, 2);
				stmt.addBatch();
				
				stmt.setString(1, "chennai");
				stmt.setInt(2, 4);
				stmt.addBatch();
				
				stmt.setString(1, "pune");
				stmt.setInt(2, 6);
				stmt.addBatch();
				
				stmt.executeBatch();
				System.out.println("Check db for update");
				
			}
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		
		finally
		{
			try 
			{
				JdbcUtility.closeResource(connect, stmt, rs);
			} 
			catch (SQLException e) 
			{
				
				e.printStackTrace();
			}
		}

	}

}
