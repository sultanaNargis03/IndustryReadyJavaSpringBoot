
public class LaunchMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LaunchEmployee emp=new LaunchEmployee();
		emp.setId(1);
		emp.setName("Rohan");
		emp.setCity("Bengaluru");
		emp.setAge(15);
		
		System.out.println(emp);

	}

}
