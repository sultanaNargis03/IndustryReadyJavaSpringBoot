import lombok.Data;

//@Setter
//@Getter
//@AllArgsConstructor
//@ToString
@Data
public class LaunchEmployee 
{
	
  private Integer id;
 
  private String name;
  private Integer age;
  private String city;
  
}
