package com.telusko.dto;

public class CustomerDTO {
	
private String id;
	
	public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}

	private Integer cusNo;
	
	private String name;
	
	private String city;
	private Float billAmt;
	
	
	

	public Float getBillAmt() {
		return billAmt;
	}

	public void setBillAmt(Float billAmt) {
		this.billAmt = billAmt;
	}

	public CustomerDTO(String id, Integer cusNo, String name, String city, Float billAmt) {
		super();
		this.id = id;
		this.cusNo = cusNo;
		this.name = name;
		this.city = city;
		this.billAmt = billAmt;
	}

	@Override
	public String toString() {
		return "CustomerDTO [id=" + id + ", cusNo=" + cusNo + ", name=" + name + ", city=" + city + ", billAmt="
				+ billAmt + "]";
	}

	public CustomerDTO()
	{
		System.out.println("Zero param customer obj");
	}

	public Integer getCusNo() {
		return cusNo;
	}

	public void setCusNo(Integer cusNo) {
		this.cusNo = cusNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	




	

}
