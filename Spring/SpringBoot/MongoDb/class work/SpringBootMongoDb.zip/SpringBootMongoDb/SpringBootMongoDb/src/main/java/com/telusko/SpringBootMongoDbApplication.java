package com.telusko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.telusko.dto.CustomerDTO;
import com.telusko.generator.IdGenerator;
import com.telusko.service.CustomerServiceImpl;

@SpringBootApplication
public class SpringBootMongoDbApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(SpringBootMongoDbApplication.class, args);
	
	CustomerServiceImpl service = context.getBean(CustomerServiceImpl.class);
	
	
//	String status=service.registerCustomer(new CustomerDTO(102, "Rahul", "Chennai"));
//	System.out.println(status);
//	CustomerDTO dto=new CustomerDTO();
//	dto.setId(IdGenerator.generateId());
//	dto.setCusNo(110);dto.setName("Kamil");
//	dto.setCity("EU");
//	dto.setBillAmt(554.5f);
//	
//	String status=service.registerCustomer(dto);
//	System.out.println(status);
//	
//	service.findAllCustomers().forEach(cus->System.out.println(cus));
//	String status=service.removeDocument("65ae9f0c571d9164e2caa2b9");
//	System.out.println(status);
	
	service.fetchByBillAmtBetween(340f, 580f).forEach(c->System.out.println(c));
	
	context.close();
	
	}

}
