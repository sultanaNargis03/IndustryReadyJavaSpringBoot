package com.telusko.view;

public interface View {

}
