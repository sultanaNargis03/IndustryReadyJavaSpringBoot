package com.telusko.view;

public interface ResultView3 extends View {
	
	public Integer getPrice();

}
