package com.telusko.view;

public interface ResultView2 extends View {
	
	public Long getId();
	public String getVaccineCompany();
	public String getVaccineName();

}
