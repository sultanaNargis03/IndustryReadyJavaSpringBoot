package com.telusko.view;

public interface ResultView1 extends View {
  
	public Long getId();
	public String getVaccineCompany();
}
