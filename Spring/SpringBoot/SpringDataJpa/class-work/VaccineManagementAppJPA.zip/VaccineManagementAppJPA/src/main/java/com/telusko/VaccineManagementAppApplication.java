package com.telusko;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.telusko.bo.VaccineDetails;
import com.telusko.service.VaccineManagementImpl;

@SpringBootApplication
public class VaccineManagementAppApplication {

	public static void main(String[] args) {
	ConfigurableApplicationContext context = SpringApplication.run(VaccineManagementAppApplication.class, args);
	
	VaccineManagementImpl service = context.getBean(VaccineManagementImpl.class);
//	VaccineDetails vaccine=new VaccineDetails("Covaxin", "BharatBio", 45454);
////	service.searchVaccineByGivenData(vaccine, true, "vaccineName", "vaccineCompany").
////	forEach(v->System.out.println(v.getVaccineName() + " : "+ v.getVaccineCompany()));
//	
//	service.searchVaccineByGivenObject(vaccine).forEach(v->System.out.println(v));
	
//	System.out.println(service.searchVaccineById(6L));
	
	List<Long> ids=new ArrayList<>();
	ids.add(1L);
	ids.add(7L);
	ids.add(8L);
	
	System.out.println(service.removeVaccineByIds(ids));

	
	context.close();
	}

}
