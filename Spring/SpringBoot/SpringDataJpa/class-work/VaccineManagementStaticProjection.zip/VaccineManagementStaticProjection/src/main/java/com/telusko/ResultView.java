package com.telusko;

public interface ResultView 
{
	public String getVaccineName();
	public String getVaccineCompany();
}
