package com.telusko.service;

import com.telusko.model.Person;
import com.telusko.model.PhoneNumber;

public interface IPersonalInfoManagementService {
	
	public String savePerson(Person person);
	
	public String savePhoneNumbers(Iterable<PhoneNumber> numbers);

}
