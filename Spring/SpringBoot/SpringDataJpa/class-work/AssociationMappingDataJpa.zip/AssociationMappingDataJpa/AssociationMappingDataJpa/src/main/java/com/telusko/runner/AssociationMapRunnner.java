package com.telusko.runner;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.telusko.model.Person;
import com.telusko.model.PhoneNumber;
import com.telusko.service.PersonMngServiceImpl;

@Component
public class AssociationMapRunnner implements CommandLineRunner {

	@Autowired
	private PersonMngServiceImpl service;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

		/*
		 * Person person=new Person("Naveen", "HYD");
		 * 
		 * PhoneNumber p1=new PhoneNumber(6453627L, "Airtel"); PhoneNumber p2=new
		 * PhoneNumber(46353635L, "JIO"); p1.setPerson(person); p2.setPerson(person);
		 * 
		 * Set<PhoneNumber> contactDetails = Set.of(p1, p2);
		 * 
		 * person.setContactDetails(contactDetails);
		 * 
		 * String status=service.savePerson(person); System.out.println(status);
		 */
		
		
		  Person person=new Person("Deb", "KOL");
		  PhoneNumber p1=new PhoneNumber(6453627L, "Airtel"); 
		  PhoneNumber p2=new PhoneNumber(46353635L, "JIO"); 
		  
		  p1.setPerson(person); 
		  p2.setPerson(person);
		  
		  Set<PhoneNumber> contactDetails = Set.of(p1, p2);
		  
		  person.setContactDetails(contactDetails);
		  
		  String status=service.savePhoneNumbers(contactDetails);
		  System.out.println(status);
		
		

	}

}
