package com.telusko;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerManagementAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
