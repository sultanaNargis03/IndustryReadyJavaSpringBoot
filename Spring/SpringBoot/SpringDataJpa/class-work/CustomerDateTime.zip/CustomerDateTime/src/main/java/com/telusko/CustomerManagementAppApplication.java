package com.telusko;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.telusko.bo.CustomerDetails;
import com.telusko.service.CustomerServiceImpl;

@SpringBootApplication
public class CustomerManagementAppApplication {

	public static void main(String[] args) {
	ConfigurableApplicationContext context = SpringApplication.run(CustomerManagementAppApplication.class, args);
	
	CustomerServiceImpl service = context.getBean(CustomerServiceImpl.class);
	
//	CustomerDetails customer = new CustomerDetails("Rohan", "Bengaluru", LocalDateTime.of(1999, 03, 8, 12, 14, 8), 
//			LocalTime.of(20, 32), LocalDate.of(2024, 01, 16));
//	
//	String status=service.registerCustomer(customer);
//	System.out.println(status);
	
	service.getAllCustomer().forEach(c->System.out.println(c));
	
	
	context.close();
	}

}
