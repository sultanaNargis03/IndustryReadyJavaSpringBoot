package com.telusko;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.telusko.bo.VaccineDetails;
import com.telusko.service.VaccineManagementImpl;

@SpringBootApplication
public class VaccineManagementAppApplication {

	public static void main(String[] args) {
	ConfigurableApplicationContext context = SpringApplication.run(VaccineManagementAppApplication.class, args);
	
	VaccineManagementImpl service = context.getBean(VaccineManagementImpl.class);
//	
//       Iterable<VaccineDetails> Vaccinelist = service.fetchDetails(false, "vaccineName", "vaccineCompany");
//        Vaccinelist.forEach((c)->System.out.println(c.getVaccineName() + " => " + c.getVaccineCompany()));
//	
//	service.fetchDetailsByPgNo(0, 3, true, "vaccineName",  "vaccineCompany").
//	forEach((c)->System.out.println(c.getVaccineName() + " => " + c.getVaccineCompany()));
	service.fetchDetailsByPagination(2);
	context.close();
	}

}
