package com.telusko;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.telusko.bo.JobSeeker;
import com.telusko.service.JobSeekerServiceImpl;

@SpringBootApplication
public class JobSeekerAppApplication {

	public static void main(String[] args) throws IOException {
	ConfigurableApplicationContext context = SpringApplication.run(JobSeekerAppApplication.class, args);
	JobSeekerServiceImpl service = context.getBean(JobSeekerServiceImpl.class);
	
//	InputStream input=null;
//	FileReader reader=null;
//	byte image[]=null;
//	char textFile[]=null;
//	
//	try 
//	{
//		 input=new FileInputStream("D:\\LOB\\hyder.JPG");
//		  image=new byte[input.available()];
//		  input.read(image);
//		
//		 File file=new File("D:\\LOB\\bio.txt");
//		 reader=new FileReader(file);
//		 textFile=new char[(int) file.length()];
//		 reader.read(textFile);
//		 
//	} 
//	
//	catch (FileNotFoundException e) 
//	{
//	
//		e.printStackTrace();
//	}
//	catch (Exception e) 
//	{
//	
//		e.printStackTrace();
//	}
//	
//
//	
//	
//	JobSeeker job=new JobSeeker("Alien" , "Bengaluru", image, textFile);
//	
//	String status=service.registerJobSeeker(job);
//	System.out.println(status);
//	
//	
//	
//	try {
//		reader.close();
//		input.close();
//	} catch (IOException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
	Integer id=1;
	Optional<JobSeeker> optional = service.getDetailsById(id);
	if(optional.isPresent())
	{
		JobSeeker job = optional.get();
		System.out.println(job.getId()+ " : "+ job.getName() + " "+ job.getCity());
		OutputStream output=new FileOutputStream("hyder.JPG");
		output.write(job.getImage());
		output.flush();
		
		FileWriter writer=new FileWriter("Bio.txt");
		writer.write(job.getTextFile());
		writer.flush();
	}
	else
	{
		System.out.println("There is no record with the given id : "+ id);
	}
	
	
	context.close();
	}

}
