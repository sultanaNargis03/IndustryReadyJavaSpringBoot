package com.telusko.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LaunchApi {
	
	@GetMapping("/api")
	public String message()
	{
		return "Api developed using Gradle Built tool!";
	}

}
