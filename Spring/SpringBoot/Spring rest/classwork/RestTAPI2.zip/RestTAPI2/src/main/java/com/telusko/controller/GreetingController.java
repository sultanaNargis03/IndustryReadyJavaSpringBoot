package com.telusko.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api")
public class GreetingController 
{
	public GreetingController()
	{
		System.out.println("GreetingController bean created");
	}
	
	@GetMapping("/welcome")
	public String generateGreetings()
	{
		String body="Hello All Welcome Back";
		return body;
	}
	
	@GetMapping("/welcomeDP")
	public String generateWelcomeMessage(@RequestParam(value="name", required=false,
	defaultValue="Alien")String name)
	{
		String body="Hello! "+ name+"  Welcome Back to DP classes";
		return body;
	}
	@GetMapping("/welcomeDSA/{name}")
	public String generateCourseMessage(@PathVariable(value="name", required=false)
	String name)
	{
		String body="Hello! "+ name+"  Welcome Back to DP classes";
		return body;
	}
}
