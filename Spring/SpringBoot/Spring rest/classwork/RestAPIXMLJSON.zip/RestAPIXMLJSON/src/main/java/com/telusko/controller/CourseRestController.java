package com.telusko.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.telusko.pojo.Course;

@RestController
public class CourseRestController 
{
   
	@GetMapping(
			value ="/courseinfo", 
			produces={"application/xml","application/json"}
	)
	public Course getCourse()
	{
		//retrive this from db
		Course course=new Course();
		course.setCid(101);
		course.setCname("DevOps");
		course.setPrice(4545.5);
		return course;
	}
}
