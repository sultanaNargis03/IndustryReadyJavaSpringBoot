package com.telusko.service;

import java.net.URI;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersUriSpec;

import com.telusko.request.Passenger;
import com.telusko.response.Ticket;

@Service
public class BookingTicketServiceImpl implements IBookingTicketService
{

	private static final String BOOK_URL = 
			"http://localhost:8484/TicketBookingApp/api/ticket-booking/getTicketNumber";
	private static final String GET_URL = 
			"http://localhost:8484/TicketBookingApp/api/ticket-booking/getTicket/{ticketNumber}";


	@Override
	public Ticket bookTicket(Passenger passenger) {
		System.out.println(passenger + " in Integration logic method");
//		RestTemplate restTemplate = new RestTemplate();
//		ResponseEntity<Ticket> response=restTemplate.postForEntity(BOOK_URL, passenger, Ticket.class);
//		return response.getBody();
		
		//Get the WebClient Object
		WebClient webClient = WebClient.create();
		
		//Send the request and process the data 
		Ticket ticket=webClient.post().
		uri(BOOK_URL).
		bodyValue(passenger).
		retrieve().
		bodyToMono(Ticket.class).
		block();//synch
		return ticket;
		
	}

	@Override
	public Ticket fetchTicketInfo(Integer ticketNumber) {
//		RestTemplate restTemplate=new RestTemplate();
//		ResponseEntity<Ticket> responseEntity = restTemplate.getForEntity(GET_URL, Ticket.class, ticketNumber);
//		Ticket ticket=responseEntity.getBody();
//		System.out.println("Ticket object in Consumer service IL "+ ticket);
//		return ticket;
		
		//Get the WebClient Object
		WebClient webClient = WebClient.create();
		
		Ticket ticket = webClient.get()
				.uri(GET_URL,ticketNumber).
				retrieve().
				bodyToMono(Ticket.class).
				block();
		
//		String str="alieN";
////		String lower = str.toLowerCase();
////		String upper=lower.toUpperCase();
////		upper.length();
//		int len=str.toLowerCase().toUpperCase().length();
	
		return ticket;
	}

}
