package com.telusko.SpringBootBanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
