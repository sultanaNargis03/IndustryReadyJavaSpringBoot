package com.telusko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.reactive.function.client.WebClient;

import com.telusko.response.Ticket;

@SpringBootApplication
public class TciketBookingWebAppApplication {
	private static final String GET_URL = 
			"http://localhost:8484/TicketBookingApp/api/ticket-booking/getTicket/{ticketNumber}";


	public static void main(String[] args) {
		SpringApplication.run(TciketBookingWebAppApplication.class, args);
		System.out.println("Request to API started......");
		
		//Get the WebClient Object
				WebClient webClient = WebClient.create();
				
				//String ticket= webClient.get()
				webClient.get()
						.uri(GET_URL,112).
						retrieve().
						bodyToMono(String.class).subscribe(TciketBookingWebAppApplication::handleResponse);
						//block();//synch
				//System.out.println(ticket);		
				System.out.println("Request to API ended....");
				
	}
	public static void handleResponse(String ticket)
	{
		System.out.println(ticket);
	}

}
