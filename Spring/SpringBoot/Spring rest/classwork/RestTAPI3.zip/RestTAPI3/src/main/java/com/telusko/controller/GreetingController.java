package com.telusko.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.telusko.pojo.Implementer;


@RestController
@RequestMapping("/api")
public class GreetingController 
{
	
	@GetMapping("/implementerInfo")
	public Implementer generateGreetings()
	{
		Implementer impl=new Implementer();
		impl.setId(101);
		impl.setName("Kamil");
		impl.setCity("EU");
		return impl;
	}
	
	
}
