package com.telusko.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.telusko.pojo.Passenger;
import com.telusko.pojo.Ticket;
import com.telusko.service.ITicketBookingService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/ticket-booking")
@Tag(name="TicketBookingAPI", description = " API is to book Tickets")
public class TicketBookingController 
{
	@Autowired
   private ITicketBookingService service;
	
	@Operation(summary="POST operation", description = " API will accept json passenger obj and return ticket number")
	@PostMapping("/getTicketNumber")
	public ResponseEntity<Ticket> enrollPassenger(@RequestBody Passenger passenger)
	{
		Passenger pas=service.registerPassenger(passenger);
		Ticket ticket =new Ticket();
	
		ticket.setTicketNumber(pas.getPid());
		
		return new ResponseEntity<Ticket>(ticket, HttpStatus.OK);		
		
		
	}
	@Operation(summary="GET operation", description = " API will accept json passenger ticket number and return ticket info")
	@GetMapping("/getTicket/{ticketNumber}")
	public ResponseEntity<Ticket> getTicket(@PathVariable("ticketNumber")Integer ticketNumber)
	{
		Ticket ticket=new Ticket();
		Passenger pass = service.getPassengerInfo(ticketNumber);
		ticket.setTicketNumber(pass.getPid());
		ticket.setName(pass.getName());
		ticket.setDepature(pass.getDepature());
		ticket.setArrival(pass.getArrival());
		ticket.setDateOfJourney(pass.getDateOfJourney());
		ticket.setStatus("Confirmed");
		return new ResponseEntity<Ticket>(ticket, HttpStatus.OK);
	}
	
}
