package com.telusko.main;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telusko.pojo.Implementer;

public class LaunchJackson 
{
	public static void main(String[] args) throws JsonProcessingException 
	{
		
            Implementer impl1=new Implementer();
            
            impl1.setId(1);
            impl1.setName("Alien");
            impl1.setCity("Bengaluru");
 //           System.out.println(impl);
            
            Implementer impl2=new Implementer();
            
            impl2.setId(2);
            impl2.setName("Shweta");
            impl2.setCity("Newyork");
            
            Implementer impl3=new Implementer();
            
            impl3.setId(1);
            impl3.setName("Prakash");
            impl3.setCity("BLR");
            
            List<Implementer> list=new ArrayList<>();
            list.add(impl1);
            list.add(impl2);
            list.add(impl3);
            
            ObjectMapper mapper = new ObjectMapper();
//            String json=mapper.writeValueAsString(impl);
            String json=mapper.writerWithDefaultPrettyPrinter().writeValueAsString(list);
            System.out.println(json);
	}

}
