package com.telusko.pojo;

import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
//@JsonIgnoreProperties(ignoreUnknown=true)
public class Implementer 
{
   private Integer id;
   private String name;
   private String city;
   private String[] teamNames;
   private List<String> studies;
   
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String[] getTeamNames() {
	return teamNames;
}
public void setTeamNames(String[] teamNames) {
	this.teamNames = teamNames;
}
public List<String> getStudies() {
	return studies;
}
public void setStudies(List<String> studies) {
	this.studies = studies;
}
@Override
public String toString() {
	return "Implementer [id=" + id + ", name=" + name + ", city=" + city + ", teamNames=" + Arrays.toString(teamNames)
			+ ", studies=" + studies + "]";
}

   
   
}
