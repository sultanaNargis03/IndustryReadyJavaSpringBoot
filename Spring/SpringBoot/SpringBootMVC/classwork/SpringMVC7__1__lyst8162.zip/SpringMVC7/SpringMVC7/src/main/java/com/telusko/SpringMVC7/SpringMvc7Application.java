package com.telusko.SpringMVC7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvc7Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvc7Application.class, args);
	}

}
