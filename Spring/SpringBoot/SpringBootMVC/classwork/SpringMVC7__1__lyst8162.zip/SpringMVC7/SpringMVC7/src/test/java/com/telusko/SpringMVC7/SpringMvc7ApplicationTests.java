package com.telusko.SpringMVC7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvc7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
