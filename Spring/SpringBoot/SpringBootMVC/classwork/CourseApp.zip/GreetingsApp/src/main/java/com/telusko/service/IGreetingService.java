package com.telusko.service;

public interface IGreetingService {
      public String generateGreetings();
}
