package com.telusko.controller;



import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.telusko.pojo.Course;

@Controller
public class CourseController 
{
//	@GetMapping("/coursedetails")
//	public String getCourseDetails(Model model)
//	{
//		model.addAttribute("cid", "T1");
//		model.addAttribute("cname", "RestFul services and Microservices");
//		model.addAttribute("cprice", "4999 INR");
//		
//		return "course";
//	}
	
//	@GetMapping("/courseinfo")
//	public String getCourseInfo(Model model)
//	{
//		Course course=new Course();
//		course.setCid(1);
//		course.setCname("DevOps with AWS");
//		course.setCourseDuration("3 months");
//		course.setPrice(9999.5);
//		
//		model.addAttribute("course", course);
//		
//		return "courseinfo";
//	}
	@GetMapping({"/courseinfo","/course", "/coursedetails"})
	public String getCourseInfo(Model model)
	{
		Course course=new Course();
		course.setCid(1);
		course.setCname("DevOps with AWS");
		course.setCourseDuration("3 months");
		course.setPrice(9999.5);
		
		model.addAttribute("course", course);
		
		return "courseinfo";
	}
	

}
