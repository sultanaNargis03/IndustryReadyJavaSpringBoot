package com.telusko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCrmAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCrmAppApplication.class, args);
	}

}
