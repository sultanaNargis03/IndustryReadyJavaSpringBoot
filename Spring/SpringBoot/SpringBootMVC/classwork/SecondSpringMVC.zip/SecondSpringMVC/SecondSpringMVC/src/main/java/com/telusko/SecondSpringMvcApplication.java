package com.telusko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecondSpringMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecondSpringMvcApplication.class, args);
	}

}
