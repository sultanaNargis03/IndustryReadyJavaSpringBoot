package com.telusko.beans;

public interface Course 
{
    boolean selectCourse(double amount);
}
