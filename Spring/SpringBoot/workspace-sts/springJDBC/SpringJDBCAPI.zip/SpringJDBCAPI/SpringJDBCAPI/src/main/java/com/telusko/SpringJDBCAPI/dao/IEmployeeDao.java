package com.telusko.SpringJDBCAPI.dao;

import java.util.List;

public interface IEmployeeDao 
{
	List<Employee> getTheEmployee();

}
