--create table student(
--id int not null,
--name varchar(45)not null,
--city varchar(44)not null,
--primary key(id)
--);
create table course(cid int, cname varchar(255), primary key(cid));