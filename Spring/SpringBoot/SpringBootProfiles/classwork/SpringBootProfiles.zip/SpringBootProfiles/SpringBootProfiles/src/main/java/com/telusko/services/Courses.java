package com.telusko.services;

public interface Courses 
{
	public boolean registerToCourse(Double cost);
	
}
