package com.telusko.util;

public class AppConstants 
{
	public static final String TOPIC_NAME = "telusko-topic";
	public static final String HOST_URL = "localhost:9092";
}
