
public interface DeliveryService 
{
	boolean courierService(double amnt);

}
