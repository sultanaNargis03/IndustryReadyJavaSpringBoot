package com.telusko.beans;


public class Amazon 
{
    private CourierService service;
    
//    static 
//    {
//    	System.out.println("Amazon class is loaded");
//    }
    
    public Amazon()
    {
    	System.out.println("Amazon obj is created");
    }
    public Amazon(CourierService service)
    {
    	this.service = service;
    }
    
	public void setService(CourierService service) 
	{
		this.service = service;
	}



	public boolean initiateDelivery(double amount)
	{
		
		return service.courierService(amount);
	}
}

