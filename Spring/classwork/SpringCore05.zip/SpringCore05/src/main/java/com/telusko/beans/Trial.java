package com.telusko.beans;

public interface Trial {
  void disp();
}
