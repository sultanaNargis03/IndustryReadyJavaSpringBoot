package com.telusko.service;

import org.springframework.stereotype.Service;

@Service
public class BusinessLogic //businessLogic 
{
	public BusinessLogic()
	{
		System.out.println("Service obj is created");
	}

}
