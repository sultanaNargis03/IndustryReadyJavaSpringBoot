package com.telusko.util;

import org.springframework.stereotype.Component;

@Component
public class Util 
{
   public Util()
   {
	   System.out.println("Util obj is created");
   }
}
