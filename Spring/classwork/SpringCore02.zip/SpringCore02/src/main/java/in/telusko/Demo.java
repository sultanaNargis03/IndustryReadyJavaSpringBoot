package in.telusko;

import org.springframework.stereotype.Component;

@Component
public class Demo {
	
	public Demo()
	{
		System.out.println("Demo obj created");
	}

}
