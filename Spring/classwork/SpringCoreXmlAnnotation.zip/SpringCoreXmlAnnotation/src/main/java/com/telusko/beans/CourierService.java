package com.telusko.beans;

public interface CourierService 
{
	boolean courierService(double amnt);
}
